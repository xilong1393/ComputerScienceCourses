import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.Socket;

public class InetClient {

	public static void main(String[] args) {
		String serverName;
		if(args.length<1) 
			serverName="localhost"; //default server is localhost, we can change it if the server is on another machine
		else 
			serverName=args[0];
		
		System.out.println("Xilong Yu's Inet Client, 1.8.\n");
		System.out.println("Using server: "+serverName+", Port: 1565");
		//create an input stream
		BufferedReader in =new BufferedReader(new InputStreamReader(System.in));
		
		try 
		{
			String name;
			do {
				System.out.println("Enter a hostname or an IP address, (quit) to end: ");
				System.out.flush();
				//type in the IP or hostname we want to analysis
				name =in.readLine();
				//the text typed in doesn't contain "quit"
				if(name.indexOf("quit")<0)
					getRemoteAddress(name, serverName);
			} while(name.indexOf("quit")<0);// wait for the next text to be typed in
			System.out.println("Cancelled by user request.");
		}
		catch(IOException x) 
		{
			x.printStackTrace();
		}
	}

	private static void getRemoteAddress(String name, String serverName) {
		Socket sock;
		BufferedReader fromServer;
		PrintStream toServer;
		String textFromServer;
		try {
			//open the connection to socket according to serverName, the port is set to be 1565
			sock=new Socket(serverName, 1565);
			//create an input stream from the socket
			fromServer=new BufferedReader(new InputStreamReader(sock.getInputStream()));
			//create an output stream from the socket
			toServer=new PrintStream(sock.getOutputStream());
			
			//send the typed-in text to the server
			toServer.println(name);
			toServer.flush();
			//get the output from the server, there are altogether three outputs from the server if hostname are obtained
			//if no hostname is obtained, there will be only one exception output
			for(int i=1;i<=3;i++) {
				textFromServer=fromServer.readLine();
				if(textFromServer!=null)
					System.out.println(textFromServer);
			}
			//close the socket, release the resources
			sock.close();
		}catch(IOException x) {
			System.out.println("Socket error.");
			x.printStackTrace();
		}
		
	}

}
