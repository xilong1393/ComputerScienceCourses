import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;

public class InetServer {
	public static void main(String[] args) throws IOException {
		int q_len=6; // The maximum queue length for incoming connection
		int port =1565; // the port number the socket server is binded to 
		Socket sock;
		ServerSocket servsock= new ServerSocket(port, q_len);
		System.out.println("Xilong Yu's Inet server 1.8 starting, listening at port 1565. \n");
		while(true) {
			sock=servsock.accept(); //always waiting for the next client request
			new Worker(sock).start();//create a new worker to handle the new client request
		}
	}
}

class Worker extends Thread{
	Socket sock;
	Worker(Socket s) {
		sock=s;
	}
	
	public void run() {
		PrintStream out = null;
		BufferedReader in = null;
		try {
			// create an input stream from the socket
			in = new BufferedReader(new InputStreamReader(sock.getInputStream()));
			// create an out stream from the socket
			out = new PrintStream(sock.getOutputStream());
			try {
				String name;
				//wait for the input from the client
				name=in.readLine();
				System.out.println("Looking up "+name);
				printRemoteAddress(name, out);
			}catch(IOException x) {
				System.out.println("Server read error");
				 x.printStackTrace ();
			}
			sock.close();
		}catch(IOException ioe) {
			System.out.println(ioe);
		}
	}
	
	private void printRemoteAddress(String name, PrintStream out) {
		try {
			//output to the socket so that it can be displayed on the client side
			out.println("Looking up "+name+"...");
			InetAddress machine=InetAddress.getByName(name);
			out.println("Host name : "+ machine.getHostName());
			out.println("Host IP : "+toText(machine.getAddress()));
		}catch(UnknownHostException ex) {
			out.println("Failed in attempt to look up "+ name);
		}
		
	}
	
	private String toText(byte[] ip) {
		StringBuilder sb =new StringBuilder();
		for(int i=0;i<ip.length;++i) {
			if(i>0) sb.append(".");
			sb.append(0xff & ip[i]);
		}
		return sb.toString();
	}
}
