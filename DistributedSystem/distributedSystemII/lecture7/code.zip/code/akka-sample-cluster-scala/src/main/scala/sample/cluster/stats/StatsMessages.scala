package sample.cluster.stats

trait Messages
final case class StatsJob(text: String) extends Messages
final case class StatsResult(meanWordLength: Double) extends Messages
final case class JobFailed(reason: String) extends Messages
