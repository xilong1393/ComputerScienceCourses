package sample.cluster.transformation

//#messages
trait Messages
final case class TransformationJob(text: String) extends Messages
final case class TransformationResult(text: String) extends Messages
final case class JobFailed(reason: String, job: TransformationJob) extends Messages
case object BackendRegistration extends Messages
//#messages
