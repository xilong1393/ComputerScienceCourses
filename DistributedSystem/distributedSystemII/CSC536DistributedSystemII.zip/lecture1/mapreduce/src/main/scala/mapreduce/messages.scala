package mapreduce

case class Word(word: String, count: Int)
case object Flush
case object Done
