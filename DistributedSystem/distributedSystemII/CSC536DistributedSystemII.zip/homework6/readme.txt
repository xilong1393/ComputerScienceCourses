1. go to the folder "remote", sbt->run
2. go to the folder "problem2", sbt->run
3. close the remote window, wait a little while and message will appear on window 2