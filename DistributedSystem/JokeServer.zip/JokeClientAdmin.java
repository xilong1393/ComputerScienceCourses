/*
1. Xilong Yu / 01/24/2020
2. java version: (build 1.8.0_231-b11)
3. window compile command: javac -cp ".;jackson-annotations-2.9.8.jar;jackson-core-2.9.8.jar;jackson-databind-2.9.8.jar" jokeclientadmin.java
4. window console app run command: 
	no parameter: java -cp ".;jackson-annotations-2.9.8.jar;jackson-core-2.9.8.jar;jackson-databind-2.9.8.jar" JokeClientAdmin
	one parameter: java -cp ".;jackson-annotations-2.9.8.jar;jackson-core-2.9.8.jar;jackson-databind-2.9.8.jar" JokeClientAdmin 75.102.248.91
	two parameters: java -cp ".;jackson-annotations-2.9.8.jar;jackson-core-2.9.8.jar;jackson-databind-2.9.8.jar" JokeClientAdmin localhost 75.102.248.91
5. files needed to run the program: 
		jackson-annotations-2.9.8.jar;
		jackson-core-2.9.8.jar;
		jackson-databind-2.9.8.jar; 
		JokeClient.java
6.  note: The jar files are used to transform a java object to its corresponding json string and sent to the server. 
	Port 5050 or 5051 is not used for this application. It's a similar application as the JokeClient, but it's sending request 
	with different header and body for the server to distinguish.
*/
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.Socket;
import java.net.UnknownHostException;

import com.fasterxml.jackson.databind.ObjectMapper;

public class JokeClientAdmin {

	static ObjectMapper objectMapper = new ObjectMapper();
	static Request request=new Request();
	static String defaultServerName="localhost";
	static String secServerName;
	static String serverName=defaultServerName;
	static int defaultPort=4545;
	static int secPort=4546;
	static int port=defaultPort;
	
	public static void main(String[] args) {
	try{
		System.out.println("Xilong Yu's JokeClientAdmin, v1.0 \n");
		if(args.length<1) {
			startConnect(serverName, defaultPort);
		}
		if(args.length>=1) {
			//set the default server to the first input
			defaultServerName=args[0];
			serverName=args[0];
			startConnect(serverName, defaultPort);
		}
		if(args.length>=2) {
			secServerName=args[1];
			startConnect(secServerName, secPort);
		}
		
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		
			while(true) {
				 System.out.println("please enter your command(Press ENTER to change the server mode, type in \"quit\" to quit the client, \"s\" to switch server, \"c\" to close the server):");
				 //Scanner scanner = new Scanner(System.in);
				 String command = in.readLine();
				//the text typed in doesn't contain "quit"
				if(command.equalsIgnoreCase("quit")) 
				{
					System.out.println("Client quit.");
					break;
				}else if (command.equalsIgnoreCase("c")) {
					request.setHeader("jokeclientadmin");
					request.setBody("close");
					String json = objectMapper.writeValueAsString(request);
					try {
						closeServer(json);
					}catch(Exception ex){
						System.out.println(ex.getMessage());
					}
				}
				else if(command.isEmpty())
				{
					request.setHeader("jokeclientadmin");
					request.setBody("changemode");
					String json = objectMapper.writeValueAsString(request);
					try {
						changeServerMode(json);
					}catch(Exception ex){
						System.out.println(ex.getMessage());
					}
				}else if(command.equalsIgnoreCase("s")) {
					if(port==defaultPort) {
						//it's okay when the secServerName is null. exception message will be printed when sending request to the server in this case
						serverName=secServerName;
						port=secPort;
						System.out.println("switched to the secondary server: "+serverName+", Port: "+port);
					}else {
						port=defaultPort;
						serverName=defaultServerName;
						System.out.println("switched to the default server: "+serverName+", Port: "+port);
					}
				}
			}
		}catch (Exception x ){
			System.out.println("there's an error.");
			x.printStackTrace(); 
		}
	}

	private static void closeServer(String request) throws Exception {
		Socket sock;
		BufferedReader fromServer;
		PrintStream toServer;
		String textFromServer;

		//Open connection to mode serverport
		sock = new Socket(serverName, port);

		// Create filter I/O streams for the socket:
		fromServer = new BufferedReader(new InputStreamReader(sock.getInputStream()));
		toServer = new PrintStream(sock.getOutputStream());
		
		// Send request or IP address to server:
		toServer.println(request); 
		toServer.flush();

		// Read response from the server,
		// and block while synchronously waiting:
		textFromServer = fromServer.readLine();
		if (textFromServer != null)
		{
			if(textFromServer.equalsIgnoreCase("2"))
				System.out.println("the server is successfully closed.");
		}
		sock.close();
	}

	private static void startConnect(String s, int p) {
		Socket sock;
		BufferedReader fromServer;
		PrintStream toServer;
		String textFromServer;
		try {
			sock=new Socket(s, p);
			//create an input stream from the socket
			fromServer=new BufferedReader(new InputStreamReader(sock.getInputStream()));
			//create an output stream from the socket
			toServer=new PrintStream(sock.getOutputStream());
			
			//send the typed-in text to the server
			request.setHeader("jokeclientadminstart");
			//transform the object to json string
			String json = objectMapper.writeValueAsString(request);
			toServer.println(json);
			toServer.flush();

			for(int i=1;i<=1;i++) {
				textFromServer=fromServer.readLine();
				if(textFromServer!=null) {
					if(textFromServer.equalsIgnoreCase("0")) {
						System.out.println("successfully connected to server: " + s + ", Port: " + p);
						System.out.println("the current server mode is Joke Mode");
					}else if(textFromServer.equalsIgnoreCase("1")) {
						System.out.println("successfully connected to server: " + s + ", Port: " + p);
						System.out.println("the current server mode is Proverb Mode");
					}
				}
			}
			//close the socket, release the resources
			sock.close();
		}catch(Exception ex) {
			System.out.println("failed to connected to server: " + s + ", Port: " + p);
		}
	}

	static void changeServerMode(String request) throws UnknownHostException, IOException {
		Socket sock;
		BufferedReader fromServer;
		PrintStream toServer;
		String textFromServer;

		//Open connection to mode serverport
		sock = new Socket(serverName, port);

		// Create filter I/O streams for the socket:
		fromServer = new BufferedReader(new InputStreamReader(sock.getInputStream()));
		toServer = new PrintStream(sock.getOutputStream());
		
		// Send request or IP address to server:
		toServer.println(request); 
		toServer.flush();

		// Read response from the server,
		// and block while synchronously waiting:
		textFromServer = fromServer.readLine();
		if (textFromServer != null)
		{
			if(textFromServer.equalsIgnoreCase("0")) 
				System.out.println("the current server mode is changed to Joke Mode");
			else if(textFromServer.equalsIgnoreCase("1")) 
				System.out.println("the current server mode is changed to Proverb Mode");
		}
		sock.close();
	}
	
	static class Request{
		private String header;
		private String body;
		public String getHeader() {
			return header;
		}
		public void setHeader(String header) {
			this.header = header;
		}
		public String getBody() {
			return body;
		}
		public void setBody(String body) {
			this.body = body;
		}
	}
}
