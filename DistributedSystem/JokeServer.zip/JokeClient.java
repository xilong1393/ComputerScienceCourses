/*
1. Xilong Yu / 01/24/2020
2. java version: (build 1.8.0_231-b11)
3. window compile command: javac -cp ".;jackson-annotations-2.9.8.jar;jackson-core-2.9.8.jar;jackson-databind-2.9.8.jar" jokeclient.java
4. window console app run command: 
	no parameter: java -cp ".;jackson-annotations-2.9.8.jar;jackson-core-2.9.8.jar;jackson-databind-2.9.8.jar" JokeClient
	one parameter: java -cp ".;jackson-annotations-2.9.8.jar;jackson-core-2.9.8.jar;jackson-databind-2.9.8.jar" JokeClient 75.102.248.91
	two parameters: java -cp ".;jackson-annotations-2.9.8.jar;jackson-core-2.9.8.jar;jackson-databind-2.9.8.jar" JokeClient localhost 75.102.248.91
5. files needed to run the program: 
		jackson-annotations-2.9.8.jar;
		jackson-core-2.9.8.jar;
		jackson-databind-2.9.8.jar; 
		JokeClientAdmin.java
6. note: The jar files are used to transform a java object to its corresponding json string and sent to the server. 
*/
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.fasterxml.jackson.databind.*;
public class JokeClient {
	static List<Integer> jokeList=new ArrayList<>();
	static List<Integer> proverbList=new ArrayList<>();
	//used to map object to json
	static ObjectMapper objectMapper = new ObjectMapper();
	static Request request=new Request();
	//record the position to be removed after getting response from the server
	static int jokePosition=-1;
	static int proverbPosition=-1;
	//default server is localhost
	static String defaultServerName="localhost";
	static String secServerName;
	static String serverName=defaultServerName;
	static int defaultPort=4545;
	static int secPort=4546;
	static int port=defaultPort;
	public static void main(String[] args) {
		try 
		{
			//start a session when the client is initiated
	    	ClientSession session = new ClientSession();
	    	//create a random number generator
	    	Random rdm=new Random();
	    	//fill the jokeList and proverbList
	    	refillList(jokeList);
	    	refillList(proverbList);
			System.out.println("Xilong Yu's Joke Client starting\n");
			if(args.length<1) {
				startConnect(serverName, defaultPort);
			}
			if(args.length>=1) {
				//set the default server to the first parameter from the command line
				defaultServerName=args[0];
				serverName=args[0];
				startConnect(serverName, defaultPort);
			}
			if(args.length>=2) {
				secServerName=args[1];
				startConnect(secServerName, secPort);
			}
				
			//create an input stream
			BufferedReader in =new BufferedReader(new InputStreamReader(System.in));
			
			//require the user to enter a valid username
			System.out.println("Please type in your name first!");
			String userName;
			while(true) {
			    userName=in.readLine();
				if(userName.trim().isEmpty()) {
					System.out.println("Please enter a valid username!");
					continue;
				}
				else {
					System.out.println("welcome, "+userName);
					break;
				}
			}
				
			while(true) {
				 System.out.println("please enter your command(Press ENTER to get a random joke or proverb, type in \"quit\" to quit the client, type \"s\" to switch server):");
				 //Scanner scanner = new Scanner(System.in);
				 String command = in.readLine();
				//the text typed in doesn't contain "quit"
				if(command.equalsIgnoreCase("quit")) 
				{
					System.out.println("Client quit.");
					break;
				}
				else if(command.isEmpty())
				{
					//much work is done here to release the burden for the server
					session.setUserName(userName);
					//random selection of a joke from the server
					int curJokePosition=rdm.nextInt(jokeList.size());
					int joke=jokeList.get(curJokePosition);
					session.setJoke(joke);
					jokePosition=curJokePosition;
					int curProverbPosition=rdm.nextInt(proverbList.size());
					int proverb=proverbList.get(curProverbPosition);
					session.setProverb(proverb);
					proverbPosition=curProverbPosition;
					//transform the object to json string
					 
					String json = objectMapper.writeValueAsString(session);
					request.setHeader("getRandomJokeOrProverb");
					request.setBody(json);
					String requestJson=objectMapper.writeValueAsString(request);
					try {
						sendCommand(requestJson);
					}
					catch(Exception ex) {
						System.out.println(ex.getMessage());
					}
				}else if(command.equalsIgnoreCase("s")) {
					if(port==defaultPort) {
						//it's okay when the secServerName is null. exception message will be printed when sending request to the server in this case
						serverName=secServerName;
						port=secPort;
						System.out.println("switched to the secondary server: "+serverName+", Port: "+port);
					}else {
						port=defaultPort;
						serverName=defaultServerName;
						System.out.println("switched to the default server: "+serverName+", Port: "+port);
					}
				}
			}
		}
	catch(Exception x) 
	{
		x.printStackTrace();
	}
}

	private static void startConnect(String s, int p) {
		Socket sock;
		BufferedReader fromServer;
		PrintStream toServer;
		String textFromServer;
		try{
			sock=new Socket(s, p);
			//create an input stream from the socket
			fromServer=new BufferedReader(new InputStreamReader(sock.getInputStream()));
			//create an output stream from the socket
			toServer=new PrintStream(sock.getOutputStream());
			
			//send the typed-in text to the server
			request.setHeader("jokeclientstart");
			//transform the object to json string
			String json = objectMapper.writeValueAsString(request);
			toServer.println(json);
			toServer.flush();

			for(int i=1;i<=1;i++) {
				textFromServer=fromServer.readLine();
				if(textFromServer!=null) {
					if(textFromServer.equalsIgnoreCase("0")) {
						System.out.println("successfully connected to server: " + s + ", Port: " + p);
						System.out.println("the current server mode is Joke Mode");
					}else if(textFromServer.equalsIgnoreCase("1")) {
						System.out.println("successfully connected to server: " + s + ", Port: " + p);
						System.out.println("the current server mode is Proverb Mode");
					}
				}
			}
			sock.close();
		}catch(Exception ex) {
			System.out.println("failed to connected to server: " + s + ", Port: " + p);
		}
	}

	private static void sendCommand(String request) {
		Socket sock;
		BufferedReader fromServer;
		PrintStream toServer;
		String textFromServer;
		try {
			//open the connection to socket according to serverName and port 
			sock=new Socket(serverName, JokeClient.port);
			//create an input stream from the socket
			fromServer=new BufferedReader(new InputStreamReader(sock.getInputStream()));
			//create an output stream from the socket
			toServer=new PrintStream(sock.getOutputStream());
			
			//send the typed-in text to the server
			toServer.println(request);
			toServer.flush();

			for(int i=1;i<=1;i++) {
				textFromServer=fromServer.readLine();
				if(textFromServer!=null) {
					String num=textFromServer.split(" ")[0];
					System.out.println(textFromServer);
					//remove the element represented by the header of the output from server
					if(num.charAt(0)=='J') {
						//directly remove at jokePosition, linear time complexity
						jokeList.remove(jokePosition);
						System.out.println("there're "+jokeList.size()+" jokes left to be fetched.");
						//refill the list if the list is empty
						if(jokeList.size()==0) {
							jokeList=refillList(jokeList);
							System.out.println("JOKE CYCLE COMPLETED.");
						}
					}
					else if(num.charAt(0)=='P') {
						//directly remove at proverbPosition, linear time complexity
						proverbList.remove(proverbPosition);
						System.out.println("there're "+proverbList.size()+" proverbs left to be fetched.");
						//refill the list if the list is empty
						if(proverbList.size()==0) {
							proverbList=refillList(proverbList);
							System.out.println("PROVERB CYCLE COMPLETED.");
						}
					}
				}
			}
			//close the socket, release the resources
			sock.close();
		}catch(Exception e) {
			System.out.println(" There's an error.");
			e.printStackTrace();
		}
	}
	
	//set the list to the initial state, with four numbers: 0,1,2,3
	private static List<Integer> refillList(List<Integer> list) {
		list.add(0);
		list.add(1);
		list.add(2);
		list.add(3);
		return list;
	}
		
	//request model, will be sent to the server in the form of json string
	static class Request{
		private String header;
		private String body;
		public String getHeader() {
			return header;
		}
		public void setHeader(String header) {
			this.header = header;
		}
		public String getBody() {
			return body;
		}
		public void setBody(String body) {
			this.body = body;
		}
	}
	//session class, will be sent to the server in the form of json string
	static class ClientSession{
		private String userName;
		private int joke;
		private int proverb;
		public String getUserName() {
			return userName;
		}
		public void setUserName(String userName) {
			this.userName = userName;
		}
		public int getJoke() {
			return joke;
		}
		public void setJoke(int joke) {
			this.joke = joke;
		}
		public int getProverb() {
			return proverb;
		}
		public void setProverb(int proverb) {
			this.proverb = proverb;
		}
	}
}


