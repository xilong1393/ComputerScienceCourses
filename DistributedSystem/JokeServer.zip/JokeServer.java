/*
 1. Xilong Yu / 01/24/2020
 2. java version: (build 1.8.0_231-b11)
 3. window compile command: javac -cp ".;jackson-annotations-2.9.8.jar;jackson-core-2.9.8.jar;jackson-databind-2.9.8.jar" jokeserver.java
 4. window console app run command: 
 	no parameter: java -cp ".;jackson-annotations-2.9.8.jar;jackson-core-2.9.8.jar;jackson-databind-2.9.8.jar" JokeServer
 	one parameter: java -cp ".;jackson-annotations-2.9.8.jar;jackson-core-2.9.8.jar;jackson-databind-2.9.8.jar" JokeServer secondary
 5. files needed to run the program: 
		jackson-annotations-2.9.8.jar;
 		jackson-core-2.9.8.jar;
 		jackson-databind-2.9.8.jar; 
 		JokeServer.java
 6. note: the jar files are used to transform request json string to an object, and do corresponding operation based on different request header and body
 	for example a request with header: jokeclientadmin are from the JokeClientAdmin application, with its request body being either close or changemode,
 	meaning different operation for the server to do.
 */
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JokeServer {
	public static List<Joke> jlist=new ArrayList<>();
	public static List<Proverb> plist=new ArrayList<>();
	//used to map a json string to object
	public static ObjectMapper objectMapper = new ObjectMapper();
	public static HashMap<String,List<Integer>[]> map=new HashMap<>(); 
	//the state of the server, 0 means joke mode and 1 means proverb mode
	public static int state=0;
	public static ServerSocket servsock;
	public static int port;
	public static void main(String[] args) throws IOException {
		try {
			int q_len=6; // maximum queue length for incoming connection
		    port =4545; // the default port number
			Socket sock;
			//default number changed to 4546 if the first parameter typed in the cmd is "secondary"
			if(args.length>=1&&args[0].equalsIgnoreCase("secondary"))
				port=4546;
		    servsock = new ServerSocket(port, q_len);
			initJokeAndProverb();
			System.out.println("Xilong Yu's Joke server starting, listening at port "+port+". \n");
			if(port==4546)
				System.out.println("This is the secondary joke server.");
			System.out.println("The server is currently in joke mode.");
			while(true) {
				sock=servsock.accept(); //always waiting for the new request from the client
				new Worker(sock).start();//create a new worker to deal with new request from client
			}
		}catch(Exception ex) {
			System.out.println(ex.getMessage());
		}
	}

	private static void initJokeAndProverb() {
		jlist.add(new Joke("JA","","I threw a boomerand a few years ago. Now I live in constant fear."));
		jlist.add(new Joke("JB","","Women only call me ugly until they find out how much money I make. Then they call me ugly and poor."));
		jlist.add(new Joke("JC","","My grandfather has the heart of a lion and a lifetime ban at the zoo."));
		jlist.add(new Joke("JD","","You don't need a parachute to go skydiving. You need a parachute to go skydiving twice."));
		
		plist.add(new Proverb("PA","","A bad workman always blames his tools."));
		plist.add(new Proverb("PB","","Beauty is in the eye of the beholder."));
		plist.add(new Proverb("PC","","Curiosity killed the cat."));
		plist.add(new Proverb("PD","","Don�t cast pearls before swine."));
	}
}

class Worker extends Thread{
	Socket sock;
	Worker(Socket s) {
		sock=s;
	}
	
	public void run() {
		PrintStream out = null;
		BufferedReader in = null;
		try {
			// create an input stream from the socket
			in = new BufferedReader(new InputStreamReader(sock.getInputStream()));
			// create an out stream from the socket
			out = new PrintStream(sock.getOutputStream());
			
				//wait for the input from the client
				String requestString = in.readLine();
				ObjectMapper objectMapper = new ObjectMapper();
				Request request = objectMapper.readValue(requestString, Request.class);
				//response to request with four types of header
				if(request.getHeader().equalsIgnoreCase("jokeclientstart")) {
					System.out.println("A JokeClient is started and connected to this server!");
					out.println(JokeServer.state);
				}
				else if(request.getHeader().equalsIgnoreCase("jokeclientadminStart")) {
					System.out.println("A JokeClientAdmin is started and connected to this server!");
					out.println(JokeServer.state);
				}else if(request.getHeader().equalsIgnoreCase("jokeclientadmin")) {
					if(request.getBody().equalsIgnoreCase("close")) {
						out.println(2);
						JokeServer.servsock.close();
						return;
					}else if(request.getBody().equalsIgnoreCase("changemode")){
						if(JokeServer.state==0) {
							JokeServer.state=1;
							System.out.println("Server changed to proverb mode!");
						}else {
							JokeServer.state=0;
							System.out.println("Server changed to joke mode!");
						}
						out.println(JokeServer.state);
					}
				}else if(request.getHeader().equalsIgnoreCase("getRandomJokeOrProverb"))
					returnRandomJokeOrProverb(request.getBody(), out);
		}catch(IOException e) {
			out.print("Server error");
			e.printStackTrace();
		}
		finally {
			try {
				sock.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	private void returnRandomJokeOrProverb(String cilentSession, PrintStream out) throws JsonParseException, JsonMappingException, IOException {
		System.out.println("cilentSession: "+ cilentSession);
		ClientSession session = JokeServer.objectMapper.readValue(cilentSession, ClientSession.class);
		//send a joke or a proverb to the client according the state of the client
		if(JokeServer.state==0) {
			Joke joke=JokeServer.jlist.get(session.getJoke());
			joke.setNameHolder(session.getUserName());
			if(JokeServer.port==4546)
				out.println("<S2>"+joke.toString());
			else
				out.println(joke);
			System.out.println("the server is in joke mode, a joke is sent to the client.");
		}else {
			Proverb proverb=JokeServer.plist.get(session.getProverb());
			proverb.setNameHolder(session.getUserName());
			if(JokeServer.port==4546)
				out.println("<S2>"+proverb.toString());
			else
				out.println(proverb);
			System.out.println("the server is in proverb mode, a proverb is sent to the client.");
		}
	}
	static class Request{
		private String header;
		private String body;
		public String getHeader() {
			return header;
		}
		public void setHeader(String header) {
			this.header = header;
		}
		public String getBody() {
			return body;
		}
		public void setBody(String body) {
			this.body = body;
		}
	}
	
	//works as a model for the mapping the the json data from the client
	static class ClientSession {
		private String userName;
		private int joke;
		private int proverb;
	
		public String getUserName() {
			return userName;
		}
		public void setUserName(String userName) {
			this.userName = userName;
		}
		public int getJoke() {
			return joke;
		}
		public void setJoke(int joke) {
			this.joke = joke;
		}
		public int getProverb() {
			return proverb;
		}
		public void setProverb(int proverb) {
			this.proverb = proverb;
		}
	}
}

class Joke{
	private String number;
	private String nameHolder;
	private String text;
	public String getNumber() {
		return number;
	}
	public String getNameHolder() {
		return nameHolder;
	}
	public void setNameHolder(String nameHolder) {
		this.nameHolder = nameHolder;
	}
	public String getText() {
		return text;
	}
	public Joke(String number, String nameHolder, String text) {
		super();
		this.number = number;
		this.nameHolder = nameHolder;
		this.text = text;
	}
	@Override
	public String toString() {
		return number + " " + nameHolder + ": " + text;
	}
}

class Proverb{
	private String number;
	private String nameHolder;
	private String text;
	public String getNumber() {
		return number;
	}
	public String getNameHolder() {
		return nameHolder;
	}
	public void setNameHolder(String nameHolder) {
		this.nameHolder = nameHolder;
	}
	public String getText() {
		return text;
	}
	public Proverb(String number, String nameHolder, String text) {
		super();
		this.number = number;
		this.nameHolder = nameHolder;
		this.text = text;
	}
	@Override
	public String toString() {
		return number + " " + nameHolder + ": " + text;
	}
}

