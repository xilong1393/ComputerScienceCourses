public class DesEncrypt {
	static int[][] S1=new int[][]{
		{5,2,1,6,3,4,7,0},
		{1,4,6,2,0,7,5,3}
	};
	static int[][] S2=new int[][]{
		{4,0,6,5,7,1,3,2},
		{5,3,0,7,6,2,1,4}
	};
	public static void main(String[] args) {
		int res=encrypt(2933, 470);
		System.out.println(res);
	}
	static int encrypt(int plaintext, int key) {
		String plainText=getNBitString(12, plaintext);
		String[] keys=getSubKey(key);
		String str=fourRound(plainText, keys);
		int res=Integer.parseInt(str, 2);
		return res;
	}
	static String fourRound(String text, String[] keys) {
		String L=text.substring(0,6);
		String R=text.substring(6);
		for(int i=1;i<=4;i++) {
			int cur=Integer.parseInt(L, 2) ^ Integer.parseInt(f(R, keys[i]), 2);
			String sixBitString=getNBitString(6,cur);
			
			L=R;
			R=sixBitString;
		}
		return L+R;
	}
	private static String sBox1(String str) {
		int row=str.charAt(0)-'0';
		int temp=S1[row][Integer.parseInt(str.substring(1), 2)];
		return getNBitString(3,temp);
	}

	private static String sBox2(String str) {
		int row=str.charAt(0)-'0';
		int temp=S2[row][Integer.parseInt(str.substring(1), 2)];
		return getNBitString(3,temp);
	}
	static String f(String R, String key) {
		String expand=expand(R);
		int xor=Integer.parseInt(expand,2) ^ Integer.parseInt(key,2);
		String eightBitString=getNBitString(8, xor);
		String left=eightBitString.substring(0, 4);
		String right=eightBitString.substring(4);
		left=sBox1(left);
		right=sBox2(right);
		return getNBitString(6, Integer.parseInt(left+right, 2));
	}
	static String[] getSubKey(int key) {
		String[] res=new String[5];
		String keyString=getNBitString(9,key);
		res[1]=keyString.substring(0, 8);
		res[2]=keyString.substring(1);
		res[3]=keyString.substring(2)+keyString.substring(0, 1);
		res[4]=keyString.substring(3)+keyString.substring(0, 2);
		return res;
	}
	static String getNBitString(int n, int key)
	{
		String res="";
		for(int i=0;i<n;i++) {
			res=res+"0";
		}
		String binaryString=Integer.toBinaryString(key);
		int length=binaryString.length();
		res=res.substring(0, n-length)+binaryString;
		return res;
	}
	static String expand(String R) {
		StringBuilder sb=new StringBuilder();
		char[] arr=R.toCharArray();
		sb.append(arr[0]);
		sb.append(arr[1]);
		sb.append(arr[3]);
		sb.append(arr[2]);
		sb.append(arr[3]);
		sb.append(arr[2]);
		sb.append(arr[4]);
		sb.append(arr[5]);
		return sb.toString();
	}
}