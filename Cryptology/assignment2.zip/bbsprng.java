import java.math.BigInteger;

public class bbsprng{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		bbsprng();
	}

	static void bbsprng() {
		BigInteger p=new BigInteger("24672462467892469787");
		BigInteger q=new BigInteger("396736894567834589803");
		BigInteger n=p.multiply(q);
		BigInteger x=new BigInteger("873245647888478349013");
		
		BigInteger[] res=new BigInteger[10];
		res[0]=x.multiply(x).mod(n);
		for(int i=1;i<9;i++) {
			res[i]=res[i-1].multiply(res[i-1]).mod(n);
		}
		for(int i=0;i<9;i++) {
			System.out.println("x"+i+" = "+res[i]);
		}
	}
}
