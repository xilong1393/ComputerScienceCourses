public class Problem6 {
	public static void main(String[] args) {
		encrypt();
		affineCipher();
	}
	public static void encrypt() {
		char[] originalArr=new char[] {'A', 'C', 'G', 'T'};
		String s="GAATTCGCGGCCGCAATTAACCCTCACTAAAGGGATCTCTAGAACT";
		char[] arr=s.toCharArray();
		StringBuilder sb=new StringBuilder();
		for(char c:arr) {
			int index="ACGT".indexOf(c);
			int shift=(index+1)%4;
			sb.append(originalArr[shift]);
		}
		System.out.println(sb.toString());
	}

	public static void affineCipher() {
		int a=1, b=2;
		char[] originalArr=new char[] {'A', 'C', 'G', 'T'};
		String s="GAATTCGCGGCCGCAATTAACCCTCACTAAAGGGATCTCTAGAACT";
		char[] arr=s.toCharArray();
		StringBuilder sb=new StringBuilder();
		for(char c:arr) {
			int index="ACGT".indexOf(c);
			int shift=(a*index+b)%4;
			sb.append(originalArr[shift]);
		}
		System.out.println(sb.toString());
	}

	
}
