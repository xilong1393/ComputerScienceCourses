public class Problem5 {
	public static void main(String[] args) {
		decryptAll26();
		decryptWith24();
	}
	
	public static void decryptAll26() {
		String s="ycve";
		char[] arr=s.toCharArray();
		for(int i=0;i<26;i++) {
			StringBuilder sb=new StringBuilder();
			for(char c:arr) {
				sb.append((char)((c-'a'+i)%26+'a'));
			}
			System.out.println(i+"----"+sb.toString());
		}
	}
	
	public static void decryptWith24() {
		String s="ycvejqwvhqtdtwvwu";
		char[] arr=s.toCharArray();
		StringBuilder sb=new StringBuilder();
		for(char c:arr) {
			sb.append((char)((c-'a'+24)%26+'a'));
		}
		System.out.println(sb.toString());
	}
}
