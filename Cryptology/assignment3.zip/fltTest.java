import java.util.HashSet;
import java.util.Random;

public class fltTest {

	static Random r=new Random();
	public static void main(String[] args) {
		HashSet<Integer> set=new HashSet<>();
		int range=(int)Math.pow(2, 24);
		int a=0;
		int counter=0;
		int previous=0;
		while(set.size()<16) {
			++counter;
			a=r.nextInt(range)+range;
			if(isPrime(a)&&!set.contains(a)) {
				System.out.println(a+"---------The time of trials is "+(counter-previous));
				set.add(a);
				previous=counter;
			}
		}
	}
	
	public static boolean isPrime(int p ) {
		for(int i=0;i<20;i++) {
			int a=r.nextInt(p-2)+2;
			long res=modPower(a,p-1,p);
			if(res!=1)
				return false;
		}
		return true;
	}

	static long modPower(long base,long exponential,long mod) 
    { 
		long result = 1;
		long x=base;
		long y=exponential;
		   while (y != 0){
		      if ((y & 1) == 1){
		    	  result = (result * x) % mod;
		      };
		      y >>= 1;
		      x = (x * x) % mod;
		   };
		   return result;
    }
}
