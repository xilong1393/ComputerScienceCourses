

import java.math.BigInteger;
import java.util.HashMap;

public class BabyGiant {
	//1002^x=437083 (Mod 595117)
	public static void main(String[] args) {
		BigInteger p=BigInteger.valueOf(595117);
		BigInteger alpha=BigInteger.valueOf(1002);
		int N=(int)Math.sqrt(595117-1)+1;//772
		HashMap<BigInteger, BigInteger> map=new HashMap<>();
		for(int j=0;j<N;j++) 
		{
			BigInteger cur=alpha.modPow(BigInteger.valueOf(j), p);
			map.put(cur, BigInteger.valueOf(j));
		}
		for(int k=0;k<N;k++) {
			BigInteger cur=alpha.modPow(BigInteger.valueOf(-N*k), p);
			//BigInteger cur=alpha.pow(N*k).modInverse(p);
			BigInteger big=BigInteger.valueOf(437083).multiply(cur).mod(p);
			if(map.containsKey(big)) {
				BigInteger ans=map.get(big).add(BigInteger.valueOf(N*k));
				System.out.println(ans);
String s=ans.toString();
				int length=s.length();
				for(int i=0;i<length;i+=2) {
					String temp=s.substring(i,i+2);
					char c=(char)(Integer.parseInt(temp)+'A'-1);
					System.out.print(c);
				}
			}
		}
	}
}